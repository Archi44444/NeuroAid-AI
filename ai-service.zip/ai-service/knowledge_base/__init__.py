"""Knowledge base package for NeuroAid RAG system."""
